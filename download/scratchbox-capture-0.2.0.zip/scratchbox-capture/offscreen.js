let recorder = null;
let chunks = [];
let streams = [];
let filename = "Screen Recording.webm";

function stopTracks() {
  streams.forEach((stream) => {
    stream.getTracks().forEach((track) => track.stop());
  });
  streams = [];
}

function pickMime() {
  const types = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp9",
    "video/webm",
  ];
  return types.find((type) => MediaRecorder.isTypeSupported(type)) || "video/webm";
}

async function mixStreams(displayStream, micStream, wantTabAudio) {
  const videoTrack = displayStream.getVideoTracks()[0];
  const tabTracks = displayStream.getAudioTracks();
  streams.push(displayStream);
  if (micStream) streams.push(micStream);

  const ctx = new AudioContext();
  if (tabTracks.length) {
    const tab = ctx.createMediaStreamSource(new MediaStream(tabTracks));
    tab.connect(ctx.destination);
    if (!wantTabAudio && !micStream) return new MediaStream([videoTrack]);
    const dest = ctx.createMediaStreamDestination();
    if (wantTabAudio) tab.connect(dest);
    if (micStream?.getAudioTracks().length) {
      ctx.createMediaStreamSource(micStream).connect(dest);
    }
    return new MediaStream([videoTrack, ...dest.stream.getAudioTracks()]);
  }

  if (!micStream) return new MediaStream([videoTrack]);
  const dest = ctx.createMediaStreamDestination();
  ctx.createMediaStreamSource(micStream).connect(dest);
  return new MediaStream([videoTrack, ...dest.stream.getAudioTracks()]);
}

async function startTab({ streamId, tabAudio, mic, name }) {
  if (recorder) throw new Error("Already recording.");
  filename = name || filename;

  const displayStream = await navigator.mediaDevices.getUserMedia({
    video: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId,
      },
    },
    audio: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId,
      },
    },
  });
  let micStream = null;
  if (mic) {
    try {
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
        video: false,
      });
    } catch {
      displayStream.getTracks().forEach((t) => t.stop());
      throw new Error("Microphone permission denied.");
    }
  }

  const mixed = await mixStreams(displayStream, micStream, !!tabAudio);
  chunks = [];
  recorder = new MediaRecorder(mixed, { mimeType: pickMime() });
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data);
  };
  recorder.onstop = async () => {
    stopTracks();
    const blob = new Blob(chunks, { type: "video/webm" });
    const url = URL.createObjectURL(blob);
    await chrome.downloads.download({
      url,
      filename,
      saveAs: false,
      conflictAction: "uniquify",
    });
    recorder = null;
    chunks = [];
    chrome.runtime.sendMessage({ type: "recording-stopped" }).catch(() => {});
  };
  mixed.getVideoTracks()[0]?.addEventListener("ended", () => {
    if (recorder?.state === "recording") recorder.stop();
  });
  recorder.start(1000);
}

function stop() {
  if (recorder?.state === "recording" || recorder?.state === "paused") {
    recorder.stop();
    return true;
  }
  return false;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "offscreen-record-tab" && msg?.type !== "offscreen-stop") return;
  (async () => {
    try {
      if (msg.type === "offscreen-record-tab") {
        await startTab({
          streamId: msg.streamId,
          tabAudio: msg.tabAudio,
          mic: msg.mic,
          name: msg.filename,
        });
        sendResponse({ ok: true });
        return;
      }
      sendResponse({ ok: stop() });
    } catch (err) {
      sendResponse({ error: err instanceof Error ? err.message : String(err) });
    }
  })();
  return true;
});
