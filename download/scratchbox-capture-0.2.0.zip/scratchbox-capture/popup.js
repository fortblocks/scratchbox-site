const status = document.getElementById("status");
const stopBtn = document.getElementById("stop");
const recordTabBtn = document.getElementById("recordTab");
const recordScreenBtn = document.getElementById("recordScreen");
const tabAudio = document.getElementById("tabAudio");
const mic = document.getElementById("mic");

function show(msg) {
  status.hidden = false;
  status.textContent = msg;
}

function setRecordingUi(on) {
  stopBtn.hidden = !on;
  recordTabBtn.hidden = on;
  recordScreenBtn.hidden = on;
  tabAudio.disabled = on;
  mic.disabled = on;
}

async function prefs() {
  const stored = await chrome.storage.local.get({ tabAudio: true, mic: false });
  tabAudio.checked = stored.tabAudio !== false;
  mic.checked = !!stored.mic;
}

async function savePrefs() {
  await chrome.storage.local.set({
    tabAudio: tabAudio.checked,
    mic: mic.checked,
  });
}

tabAudio.addEventListener("change", savePrefs);
mic.addEventListener("change", savePrefs);

async function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, ...extra });
}

document.getElementById("visible").addEventListener("click", async () => {
  show("Capturing…");
  const res = await send("capture-visible");
  show(res?.error || "Saved to Downloads.");
});

document.getElementById("region").addEventListener("click", async () => {
  show("Drag on the page. Esc cancels.");
  const res = await send("capture-region");
  if (res?.error) show(res.error);
  else window.close();
});

document.getElementById("page").addEventListener("click", async () => {
  show("Scrolling the page…");
  const res = await send("capture-page");
  show(res?.error || "Saved to Downloads.");
});

recordTabBtn.addEventListener("click", async () => {
  await savePrefs();
  show("Starting…");
  const res = await send("record-tab", {
    tabAudio: tabAudio.checked,
    mic: mic.checked,
  });
  if (res?.error) show(res.error);
  else window.close();
});

recordScreenBtn.addEventListener("click", async () => {
  await savePrefs();
  const res = await send("record-screen", {
    tabAudio: tabAudio.checked,
    mic: mic.checked,
  });
  if (res?.error) show(res.error);
  else window.close();
});

stopBtn.addEventListener("click", async () => {
  show("Saving…");
  const res = await send("stop-recording");
  show(res?.error || "Saved to Downloads.");
  setRecordingUi(false);
});

(async () => {
  await prefs();
  const res = await send("record-status");
  setRecordingUi(!!res?.recording);
  if (res?.recording) show("Recording… click the cube or Stop to save.");
})();
