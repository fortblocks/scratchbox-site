# Scratchbox Capture

Chrome extension (Manifest V3). Local only. Version 0.2.0.

Saves into Downloads as `Screenshot …png` or `Screen Recording …webm` so the Mac app treats them like system captures when Watch Downloads is on.

## Install (until the Chrome Web Store listing ships)

1. Download the zip from [scratchbox.xyz/capture](https://scratchbox.xyz/capture).
2. Unzip it.
3. Open `chrome://extensions`.
4. Turn on **Developer mode**.
5. **Load unpacked** and pick the `scratchbox-capture` folder.
6. Pin Scratchbox Capture.

Do not load this folder from the private GitHub repo in a browser that is not signed in.

## Capture

- Visible tab
- Selected area (drag a rectangle)
- Entire page (scrolls and stitches)
- Record this tab, with optional tab audio and microphone
- Record screen or window (Chrome’s picker; check “Also share tab audio”)

Shortcuts: Option-Shift-V visible, S selection, P entire page, R this tab.

No account. No upload. Files stay on the machine.
