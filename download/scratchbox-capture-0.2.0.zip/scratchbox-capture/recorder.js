const startBtn = document.getElementById("start");
const stopBtn = document.getElementById("stop");
const status = document.getElementById("status");
const clock = document.getElementById("clock");
const params = new URLSearchParams(location.search);
const wantAudio = params.get("audio") !== "0";
const wantMic = params.get("mic") === "1";

let recorder = null;
let chunks = [];
let streams = [];
let timer = null;
let startedAt = 0;

function pad(n) {
  return String(n).padStart(2, "0");
}

function recordingName() {
  const d = new Date();
  return `Screen Recording ${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} at ${pad(d.getHours())}.${pad(d.getMinutes())}.${pad(d.getSeconds())}.webm`;
}

function pickMime() {
  const types = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp9",
    "video/webm",
  ];
  return types.find((type) => MediaRecorder.isTypeSupported(type)) || "video/webm";
}

function stopTracks() {
  streams.forEach((stream) => stream.getTracks().forEach((t) => t.stop()));
  streams = [];
}

function tick() {
  const s = Math.floor((Date.now() - startedAt) / 1000);
  clock.textContent = `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
}

async function mix(displayStream, micStream) {
  const videoTrack = displayStream.getVideoTracks()[0];
  const displayAudio = displayStream.getAudioTracks();
  streams.push(displayStream);
  if (micStream) streams.push(micStream);
  if (!displayAudio.length && !micStream) return new MediaStream([videoTrack]);

  const ctx = new AudioContext();
  const dest = ctx.createMediaStreamDestination();
  if (displayAudio.length) {
    ctx.createMediaStreamSource(new MediaStream(displayAudio)).connect(dest);
  }
  if (micStream?.getAudioTracks().length) {
    ctx.createMediaStreamSource(micStream).connect(dest);
  }
  return new MediaStream([videoTrack, ...dest.stream.getAudioTracks()]);
}

async function start() {
  status.textContent = "Pick a tab, window, or screen…";
  let displayStream;
  try {
    displayStream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 30 },
      audio: wantAudio,
      systemAudio: wantAudio ? "include" : "exclude",
      selfBrowserSurface: "exclude",
    });
  } catch {
    status.textContent = "Capture cancelled.";
    return;
  }

  let micStream = null;
  if (wantMic) {
    try {
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
        video: false,
      });
    } catch {
      stopTracks();
      displayStream.getTracks().forEach((t) => t.stop());
      status.textContent = "Microphone permission denied.";
      return;
    }
  }

  const mixed = await mix(displayStream, micStream);
  chunks = [];
  recorder = new MediaRecorder(mixed, { mimeType: pickMime() });
  recorder.ondataavailable = (e) => {
    if (e.data.size) chunks.push(e.data);
  };
  recorder.onstop = async () => {
    if (timer) clearInterval(timer);
    stopTracks();
    const blob = new Blob(chunks, { type: "video/webm" });
    const url = URL.createObjectURL(blob);
    await chrome.downloads.download({
      url,
      filename: recordingName(),
      saveAs: false,
      conflictAction: "uniquify",
    });
    await chrome.runtime.sendMessage({ type: "recording-stopped" }).catch(() => {});
    status.textContent = "Saved to Downloads as a Screen Recording.";
    startBtn.hidden = false;
    stopBtn.hidden = true;
    recorder = null;
  };
  displayStream.getVideoTracks()[0].addEventListener("ended", () => {
    if (recorder?.state === "recording") recorder.stop();
  });
  recorder.start(1000);
  startedAt = Date.now();
  tick();
  timer = setInterval(tick, 250);
  startBtn.hidden = true;
  stopBtn.hidden = false;
  status.textContent = wantMic
    ? "Recording with microphone…"
    : wantAudio
      ? "Recording. Share tab audio was requested."
      : "Recording…";
  chrome.runtime.sendMessage({ type: "recording-started" }).catch(() => {});
}

startBtn.addEventListener("click", start);
stopBtn.addEventListener("click", () => {
  if (recorder?.state === "recording") recorder.stop();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "recorder-stop" && recorder?.state === "recording") {
    recorder.stop();
  }
});

window.addEventListener("beforeunload", () => {
  if (recorder?.state === "recording") recorder.stop();
});

start();
