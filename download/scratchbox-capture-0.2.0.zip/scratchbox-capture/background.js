const MAX_CANVAS_SIDE = 16384;
const MAX_CANVAS_PIXELS = 75_000_000;
const CAPTURE_GAP_MS = 380;

let recording = false;
let recordingTabId = null;
let stopWait = null;

function pad(n) {
  return String(n).padStart(2, "0");
}

function stampName(kind, ext) {
  const d = new Date();
  const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} at ${pad(d.getHours())}.${pad(d.getMinutes())}.${pad(d.getSeconds())}`;
  const base = kind === "recording" ? "Screen Recording" : "Screenshot";
  return `${base} ${stamp}.${ext}`;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isRestrictedUrl(url = "") {
  return (
    !url ||
    /^(chrome|chrome-extension|edge|about|devtools|view-source|brave|opera|file):/i.test(url) ||
    url.startsWith("https://chrome.google.com/webstore") ||
    url.startsWith("https://chromewebstore.google.com")
  );
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab.");
  return tab;
}

async function downloadUrl(url, filename) {
  await chrome.downloads.download({
    url,
    filename,
    saveAs: false,
    conflictAction: "uniquify",
  });
}

async function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  try {
    await downloadUrl(url, filename);
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }
}

async function dataUrlToBitmap(dataUrl) {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  return createImageBitmap(blob);
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function captureVisibleTabPng(windowId) {
  return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
}

async function captureVisible() {
  const tab = await activeTab();
  if (isRestrictedUrl(tab.url)) {
    throw new Error("Can't capture this page. Open a normal website.");
  }
  const dataUrl = await captureVisibleTabPng(tab.windowId);
  await downloadUrl(dataUrl, stampName("screenshot", "png"));
}

async function startRegion() {
  const tab = await activeTab();
  if (isRestrictedUrl(tab.url)) {
    throw new Error("Can't draw on this page. Open a normal website.");
  }
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["region.js"],
  });
}

async function cropDataUrl(dataUrl, rect, dpr) {
  const bmp = await dataUrlToBitmap(dataUrl);
  const scale = dpr || 1;
  const sx = Math.max(0, Math.round(rect.x * scale));
  const sy = Math.max(0, Math.round(rect.y * scale));
  const sw = Math.max(1, Math.min(bmp.width - sx, Math.round(rect.w * scale)));
  const sh = Math.max(1, Math.min(bmp.height - sy, Math.round(rect.h * scale)));
  const canvas = new OffscreenCanvas(sw, sh);
  const ctx = canvas.getContext("2d");
  ctx.drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);
  bmp.close();
  const out = await canvas.convertToBlob({ type: "image/png" });
  return blobToDataUrl(out);
}

async function injectFullpage(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["fullpage.js"],
  });
}

async function fpCall(tabId, method, args = []) {
  const [{ result, error } = {}] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (name, fnArgs) => {
      const api = window.__scratchboxFP;
      if (!api) throw new Error("Capture helper missing.");
      return api[name](...fnArgs);
    },
    args: [method, args],
  });
  if (error) throw new Error(error.message || String(error));
  return result;
}

async function captureFullPage() {
  const tab = await activeTab();
  if (isRestrictedUrl(tab.url)) {
    throw new Error("Can't capture this page. Open a normal website.");
  }
  await injectFullpage(tab.id);
  const metrics = await fpCall(tab.id, "prepare");
  if (!metrics) throw new Error("Couldn't measure the page.");
  await chrome.action.setBadgeBackgroundColor({ color: "#0b0c0e" });
  await chrome.action.setBadgeText({ text: "…" });

  try {
    const dpr = metrics.dpr || 1;
    let canvasW = Math.max(1, Math.round(metrics.width * dpr));
    let canvasH = Math.max(1, Math.round(metrics.height * dpr));
    let scale = 1;
    if (canvasW > MAX_CANVAS_SIDE || canvasH > MAX_CANVAS_SIDE || canvasW * canvasH > MAX_CANVAS_PIXELS) {
      scale = Math.min(
        MAX_CANVAS_SIDE / canvasW,
        MAX_CANVAS_SIDE / canvasH,
        Math.sqrt(MAX_CANVAS_PIXELS / (canvasW * canvasH)),
      );
      canvasW = Math.max(1, Math.round(canvasW * scale));
      canvasH = Math.max(1, Math.round(canvasH * scale));
    }

    const canvas = new OffscreenCanvas(canvasW, canvasH);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvasW, canvasH);

    const vw = Math.max(1, metrics.vw);
    const vh = Math.max(1, metrics.vh);
    const pageW = metrics.width;
    const pageH = metrics.height;
    const maxSteps = 120;
    let steps = 0;
    let lastKey = "";

    for (let y = 0; y < pageH && steps < maxSteps; ) {
      for (let x = 0; x < pageW && steps < maxSteps; ) {
        const scrolled = await fpCall(tab.id, "scroll", [x, y, steps > 0]);
        await sleep(CAPTURE_GAP_MS);
        const dataUrl = await captureVisibleTabPng(tab.windowId);
        const bmp = await dataUrlToBitmap(dataUrl);
        const destX = Math.round((scrolled.scrollX || 0) * dpr * scale);
        const destY = Math.round((scrolled.scrollY || 0) * dpr * scale);
        const destW = Math.round(bmp.width * scale);
        const destH = Math.round(bmp.height * scale);
        ctx.drawImage(bmp, 0, 0, bmp.width, bmp.height, destX, destY, destW, destH);
        bmp.close();
        steps += 1;
        await chrome.action.setBadgeText({ text: String(steps) });

        const key = `${scrolled.scrollX},${scrolled.scrollY}`;
        const nextX = (scrolled.scrollX || 0) + vw;
        if (key === lastKey || nextX >= pageW - 1) {
          lastKey = key;
          break;
        }
        lastKey = key;
        x = nextX;
      }
      const nextY = y + vh;
      if (nextY >= pageH - 1) break;
      const probe = await fpCall(tab.id, "scroll", [0, nextY, true]);
      if ((probe.scrollY || 0) <= y) break;
      y = probe.scrollY || nextY;
      lastKey = "";
    }

    const blob = await canvas.convertToBlob({ type: "image/png" });
    await downloadBlob(blob, stampName("screenshot", "png"));
  } finally {
    await chrome.action.setBadgeText({ text: "" });
    try {
      await fpCall(tab.id, "restore");
    } catch (_) {
      /* page may have navigated */
    }
  }
}

async function setRecording(on, tabId) {
  recording = on;
  recordingTabId = on ? tabId || recordingTabId : null;
  await chrome.storage.session.set({ recording: on }).catch(() => {});
  if (on) {
    await chrome.action.setBadgeBackgroundColor({ color: "#e24b3b" });
    await chrome.action.setBadgeText({ text: "REC" });
    await chrome.action.setPopup({ popup: "" });
  } else {
    await chrome.action.setBadgeText({ text: "" });
    await chrome.action.setPopup({ popup: "popup.html" });
    try {
      await chrome.offscreen.closeDocument();
    } catch (_) {
      /* none */
    }
    if (recordingTabId) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: recordingTabId },
          func: () => {
            if (window.__scratchboxStopBar) window.__scratchboxStopBar();
          },
        });
      } catch (_) {
        /* restricted */
      }
    }
    recordingTabId = null;
  }
}

async function ensureOffscreen() {
  try {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
    });
    if (contexts && contexts.length) {
      if (recording) return;
      await chrome.offscreen.closeDocument();
    }
  } catch (_) {
    if (recording && chrome.offscreen.hasDocument && (await chrome.offscreen.hasDocument())) return;
    try {
      await chrome.offscreen.closeDocument();
    } catch (_) {
      /* none */
    }
  }
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA", "BLOBS"],
    justification: "Record the current tab, including audio, into a Screen Recording file.",
  });
}

async function recordTab({ tabAudio, mic }) {
  if (recording) throw new Error("Already recording. Click the cube to stop.");
  const tab = await activeTab();
  if (isRestrictedUrl(tab.url)) {
    throw new Error("Can't record this page. Open a normal website.");
  }
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
  await ensureOffscreen();
  const res = await chrome.runtime.sendMessage({
    type: "offscreen-record-tab",
    streamId,
    tabAudio: !!tabAudio,
    mic: !!mic,
    filename: stampName("recording", "webm"),
  });
  if (res?.error) throw new Error(res.error);
  await setRecording(true, tab.id);
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["record-bar.js"],
    });
  } catch (_) {
    /* overlay is optional */
  }
}

async function recordScreen({ tabAudio, mic }) {
  if (recording) throw new Error("Already recording. Click the cube to stop.");
  const url = chrome.runtime.getURL(
    `recorder.html?audio=${tabAudio ? "1" : "0"}&mic=${mic ? "1" : "0"}`,
  );
  await chrome.windows.create({
    url,
    type: "popup",
    width: 380,
    height: 320,
    focused: true,
  });
}

async function stopRecording() {
  const done = new Promise((resolve) => {
    stopWait = resolve;
    setTimeout(resolve, 12_000);
  });
  await chrome.runtime.sendMessage({ type: "offscreen-stop" }).catch(() => {});
  await chrome.runtime.sendMessage({ type: "recorder-stop" }).catch(() => {});
  await done;
  if (recording) await setRecording(false);
}

chrome.action.onClicked.addListener(async () => {
  if (recording) {
    try {
      await stopRecording();
    } catch (err) {
      console.warn(err);
    }
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  try {
    if (command === "capture-visible") await captureVisible();
    else if (command === "capture-region") await startRegion();
    else if (command === "capture-page") await captureFullPage();
    else if (command === "record-tab") {
      const prefs = await chrome.storage.local.get({ tabAudio: true, mic: false });
      await recordTab(prefs);
    }
  } catch (err) {
    console.warn(err);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (
    !msg?.type ||
    msg.type.startsWith("offscreen-") ||
    msg.type === "recorder-stop"
  ) {
    return;
  }
  (async () => {
    try {
      if (msg.type === "capture-visible") {
        await captureVisible();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "capture-region") {
        await startRegion();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "capture-page") {
        await captureFullPage();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "region-picked") {
        const dataUrl = await captureVisibleTabPng(sender.tab?.windowId);
        const cropped = await cropDataUrl(dataUrl, msg.rect, msg.dpr);
        await downloadUrl(cropped, stampName("screenshot", "png"));
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "record-tab") {
        await recordTab(msg);
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "record-screen") {
        await recordScreen(msg);
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "stop-recording") {
        await stopRecording();
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "record-status") {
        sendResponse({ recording });
        return;
      }
      if (msg.type === "recording-started") {
        await setRecording(true, sender.tab?.id || recordingTabId);
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "recording-stopped") {
        if (stopWait) stopWait();
        stopWait = null;
        await setRecording(false);
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === "save-recording") {
        await downloadUrl(msg.dataUrl, stampName("recording", "webm"));
        sendResponse({ ok: true });
        return;
      }
      sendResponse({ error: "Unknown request" });
    } catch (err) {
      sendResponse({ error: err instanceof Error ? err.message : String(err) });
    }
  })();
  return true;
});
