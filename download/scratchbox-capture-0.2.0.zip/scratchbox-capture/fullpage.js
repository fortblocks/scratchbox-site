(() => {
  if (window.__scratchboxFP) return;

  const STYLE_ID = "__scratchbox-fp-style";
  let saved = null;
  let sticky = [];
  let rootEl = null;

  function scrollingRoot() {
    if (rootEl && document.contains(rootEl)) return rootEl;
    const doc = document.scrollingElement || document.documentElement;
    if (doc.scrollHeight > window.innerHeight + 8) {
      rootEl = doc;
      return rootEl;
    }
    let best = doc;
    let bestScore = doc.scrollHeight;
    const nodes = document.querySelectorAll("div, main, section, article, body");
    for (const el of nodes) {
      const style = getComputedStyle(el);
      const oy = style.overflowY;
      if ((oy === "auto" || oy === "scroll") && el.scrollHeight > el.clientHeight + 80) {
        const wide = el.clientWidth > window.innerWidth * 0.55 ? 2 : 1;
        const score = el.scrollHeight * wide;
        if (score > bestScore) {
          best = el;
          bestScore = score;
        }
      }
    }
    rootEl = best;
    return rootEl;
  }

  function hideScrollbars() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent =
      "html::-webkit-scrollbar,body::-webkit-scrollbar{display:none!important}html{scrollbar-width:none!important}";
    document.documentElement.appendChild(style);
  }

  function showScrollbars() {
    document.getElementById(STYLE_ID)?.remove();
  }

  function setStickyHidden(hidden) {
    if (!hidden) {
      sticky.forEach(({ el, vis, pos }) => {
        el.style.visibility = vis;
        el.style.position = pos;
      });
      sticky = [];
      return;
    }
    if (sticky.length) return;
    const nodes = document.body ? document.body.getElementsByTagName("*") : [];
    const limit = Math.min(nodes.length, 2500);
    for (let i = 0; i < limit; i += 1) {
      const el = nodes[i];
      if (el.id === STYLE_ID) continue;
      const pos = getComputedStyle(el).position;
      if (pos === "fixed" || pos === "sticky") {
        sticky.push({
          el,
          vis: el.style.visibility,
          pos: el.style.position,
        });
        el.style.visibility = "hidden";
      }
    }
  }

  function metrics() {
    const root = scrollingRoot();
    const isDoc = root === document.scrollingElement || root === document.documentElement || root === document.body;
    const width = isDoc
      ? Math.max(
          document.documentElement.scrollWidth,
          document.body ? document.body.scrollWidth : 0,
          window.innerWidth,
        )
      : Math.max(root.scrollWidth, root.clientWidth);
    const height = isDoc
      ? Math.max(
          document.documentElement.scrollHeight,
          document.body ? document.body.scrollHeight : 0,
          window.innerHeight,
        )
      : Math.max(root.scrollHeight, root.clientHeight);
    return {
      width,
      height,
      vw: window.innerWidth,
      vh: window.innerHeight,
      dpr: window.devicePixelRatio || 1,
      scrollX: isDoc ? window.scrollX : root.scrollLeft,
      scrollY: isDoc ? window.scrollY : root.scrollTop,
    };
  }

  window.__scratchboxFP = {
    prepare() {
      const m = metrics();
      saved = { x: m.scrollX, y: m.scrollY };
      hideScrollbars();
      return m;
    },
    scroll(x, y, hideSticky) {
      const root = scrollingRoot();
      const isDoc = root === document.scrollingElement || root === document.documentElement || root === document.body;
      if (isDoc) window.scrollTo(x, y);
      else {
        root.scrollLeft = x;
        root.scrollTop = y;
      }
      setStickyHidden(!!hideSticky);
      const m = metrics();
      return { scrollX: m.scrollX, scrollY: m.scrollY };
    },
    restore() {
      setStickyHidden(false);
      showScrollbars();
      if (!saved) return;
      const root = scrollingRoot();
      const isDoc = root === document.scrollingElement || root === document.documentElement || root === document.body;
      if (isDoc) window.scrollTo(saved.x, saved.y);
      else {
        root.scrollLeft = saved.x;
        root.scrollTop = saved.y;
      }
      saved = null;
      rootEl = null;
    },
  };
})();
