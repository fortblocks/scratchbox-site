(() => {
  if (window.__scratchboxStopBar) {
    window.__scratchboxStopBar();
  }

  const host = document.createElement("div");
  host.setAttribute("data-scratchbox-bar", "1");
  host.style.cssText =
    "all:initial;position:fixed;z-index:2147483646;left:50%;bottom:24px;transform:translateX(-50%);";
  const shadow = host.attachShadow({ mode: "closed" });
  shadow.innerHTML = `
    <style>
      .bar {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 10px 8px 14px;
        background: #0b0c0e;
        color: #fff;
        font: 12px/1 ui-sans-serif, system-ui, sans-serif;
        border-radius: 999px;
        box-shadow: 0 10px 30px rgba(0,0,0,.28);
      }
      .dot {
        width: 8px; height: 8px; border-radius: 50%;
        background: #e24b3b; box-shadow: 0 0 0 3px rgba(226,75,59,.25);
      }
      button {
        border: 0; background: #fff; color: #0b0c0e;
        font: 650 12px/1 ui-sans-serif, system-ui, sans-serif;
        border-radius: 999px; padding: 7px 10px; cursor: pointer;
      }
    </style>
    <div class="bar">
      <span class="dot"></span>
      <span id="t">00:00</span>
      <button type="button" id="stop">Stop and save</button>
    </div>
  `;
  document.documentElement.appendChild(host);

  const t = shadow.getElementById("t");
  const started = Date.now();
  const timer = setInterval(() => {
    const s = Math.floor((Date.now() - started) / 1000);
    const m = String(Math.floor(s / 60)).padStart(2, "0");
    t.textContent = `${m}:${String(s % 60).padStart(2, "0")}`;
  }, 250);

  const cleanup = () => {
    clearInterval(timer);
    host.remove();
    window.__scratchboxStopBar = null;
  };

  shadow.getElementById("stop").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "stop-recording" });
    cleanup();
  });

  window.__scratchboxStopBar = cleanup;
})();
