(() => {
  if (window.__scratchboxRegion) return;
  window.__scratchboxRegion = true;

  const overlay = document.createElement("div");
  overlay.style.cssText =
    "position:fixed;inset:0;z-index:2147483646;cursor:crosshair;background:transparent;";

  const dim = document.createElement("div");
  dim.style.cssText =
    "position:fixed;inset:0;background:rgba(11,12,14,0.28);pointer-events:none;";

  const box = document.createElement("div");
  box.style.cssText =
    "position:fixed;border:1.5px solid #fff;box-shadow:0 0 0 9999px rgba(11,12,14,0.45);background:transparent;pointer-events:none;display:none;";

  const size = document.createElement("div");
  size.style.cssText =
    "position:absolute;left:0;top:-22px;font:11px/1.2 ui-sans-serif,system-ui,sans-serif;color:#fff;background:#0b0c0e;padding:3px 6px;border-radius:4px;white-space:nowrap;";

  const hint = document.createElement("div");
  hint.style.cssText =
    "position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:2147483647;font:12px/1.3 ui-sans-serif,system-ui,sans-serif;color:#fff;background:#0b0c0e;padding:8px 12px;border-radius:999px;pointer-events:none;";
  hint.textContent = "Drag to select · Esc cancels";

  box.appendChild(size);
  overlay.appendChild(dim);
  overlay.appendChild(box);
  document.documentElement.appendChild(overlay);
  document.documentElement.appendChild(hint);

  let start = null;

  const cleanup = () => {
    overlay.remove();
    hint.remove();
    window.__scratchboxRegion = false;
  };

  overlay.addEventListener("mousedown", (e) => {
    e.preventDefault();
    start = { x: e.clientX, y: e.clientY };
    dim.style.display = "none";
    box.style.display = "block";
    box.style.left = `${start.x}px`;
    box.style.top = `${start.y}px`;
    box.style.width = "0";
    box.style.height = "0";
    size.textContent = "0 × 0";
  });

  overlay.addEventListener("mousemove", (e) => {
    if (!start) return;
    const x = Math.min(start.x, e.clientX);
    const y = Math.min(start.y, e.clientY);
    const w = Math.abs(e.clientX - start.x);
    const h = Math.abs(e.clientY - start.y);
    box.style.left = `${x}px`;
    box.style.top = `${y}px`;
    box.style.width = `${w}px`;
    box.style.height = `${h}px`;
    size.textContent = `${Math.round(w)} × ${Math.round(h)}`;
  });

  overlay.addEventListener("mouseup", async (e) => {
    if (!start) return;
    const x = Math.min(start.x, e.clientX);
    const y = Math.min(start.y, e.clientY);
    const w = Math.abs(e.clientX - start.x);
    const h = Math.abs(e.clientY - start.y);
    cleanup();
    if (w < 4 || h < 4) return;
    await chrome.runtime.sendMessage({
      type: "region-picked",
      rect: { x, y, w, h },
      dpr: window.devicePixelRatio || 1,
    });
  });

  window.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "Escape") cleanup();
    },
    { once: true },
  );
})();
